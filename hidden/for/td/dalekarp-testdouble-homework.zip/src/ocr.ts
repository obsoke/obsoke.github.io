import { sortBy } from "lodash";
import { OCR_NUMBERS } from "./numberDefs";

// SETTTINGS
const ROW_LENGTH = 27;

// TYPES
type OCRNumberRepresentation = string[];

export type OCRNumber = {
  representation: OCRNumberRepresentation;
  value: number;
};

type MatchStatistic = {
  number: OCRNumber;
  matchPercentage: number;
};

enum ErrorCode {
  Error = "ERR",
  Illegible = "ILL",
  Ambiguous = "AMB",
}

function matchNumber(
  givenNumber: string[],
  potentialNumber: OCRNumber
): MatchStatistic {
  let currentMatchValue = 0;
  let length = givenNumber.length;
  for (let i = 0; i < length; i++) {
    if (givenNumber[i] === potentialNumber.representation[i]) {
      currentMatchValue += 1;
    }
  }

  return {
    number: potentialNumber,
    matchPercentage: currentMatchValue / length,
  };
}

function createPossibleNumberArray(
  accountNum: string[],
  startingColumn: number
): string[] {
  const i = startingColumn;

  // We can treat the array of strings as a pseudo-2D array, as we need to scan through
  // both the array & the string to find the desired character

  // prettier-ignore
  return [
    accountNum[0].charAt(i), accountNum[0].charAt(i + 1), accountNum[0].charAt(i + 2),
    accountNum[1].charAt(i), accountNum[1].charAt(i + 1), accountNum[1].charAt(i + 2),
    accountNum[2].charAt(i), accountNum[2].charAt(i + 1), accountNum[2].charAt(i + 2)
  ];
}

/**
 * Given an account number, calculate the checksum & confirm whether it is valid
 * or not
 *
 * @param accountNumber The account number
 * @returns A boolean representing whether the checksum is valid or not
 */
export function isChecksumValid(accountNumber: string): boolean {
  if (accountNumber.includes("?")) return false;

  let checksum = 0;
  for (let index = 8, multiplyer = 1; index >= 0; index--, multiplyer++) {
    const element = accountNumber.charAt(index);
    const number = parseInt(element, 10);
    checksum += multiplyer * number;
  }

  return checksum % 11 === 0;
}

type PotentialDigitIdentity = {
  potentialMatches: MatchStatistic[];
};
export function identifyDigit(
  possibleNumber: string[]
): PotentialDigitIdentity {
  const potentialMatches: MatchStatistic[] = [];
  for (let i = 0; i < OCR_NUMBERS.length; i++) {
    const matchResult = matchNumber(possibleNumber, OCR_NUMBERS[i]);
    if (matchResult.matchPercentage === 1) {
      return { potentialMatches: [matchResult] };
    } else {
      potentialMatches.push(matchResult);
    }
  }

  const sortedResults = sortBy(potentialMatches, (p) => p.matchPercentage); // Ascending sort
  const highestMatch = sortedResults[sortedResults.length - 1];
  const secondHighestMatch = sortedResults[sortedResults.length - 2];

  return { potentialMatches: [highestMatch, secondHighestMatch] };
}

/**
 * Given 4 lines in an account number text file, attempt to identity the account number
 *
 * @param accountNumberRepresentation An array of 4 strings, each 27 characters in length, the last line being blank
 * @returns A string representation of the acount number
 */
export function decodeAccountNumber(accountNumberRepresentation: string[]): {
  accountNumber: string;
  potentialMatches: MatchStatistic[][];
} {
  let accountNumber = "";
  let potentialMatches = [];
  for (let pointer = 0; pointer < 27; pointer += 3) {
    const possibleNumber = createPossibleNumberArray(
      accountNumberRepresentation,
      pointer
    );

    const match = identifyDigit(possibleNumber);
    if (match.potentialMatches.length === 1) {
      accountNumber += match.potentialMatches[0].number.value;
    } else {
      accountNumber += "?";
      potentialMatches.push(match.potentialMatches);
    }
  }

  return { accountNumber, potentialMatches };
}

/**
 * Given 4 lines in an account number text file, determine the final value to be written to the output account file
 *
 * @param accountNumberLines An array of 4 strings, each 27 characters in length, the last line being blank
 * @returns The string to write to an account file
 */
export function processAccountNumberLines(
  accountNumberLines: string[]
): string {
  const { accountNumber, potentialMatches } =
    decodeAccountNumber(accountNumberLines);

  if (isChecksumValid(accountNumber)) {
    return `${accountNumber}\n`;
  } else {
    // Attempt to resolve the failing checksum

    // IFF only one potential match exists, attempt to solve it
    if (potentialMatches.length === 1) {
      let validChecksums = potentialMatches[0].filter((m) => {
        let newAccountNum = accountNumber.replace("?", `${m.number}`);
        return isChecksumValid(newAccountNum);
      });

      if (validChecksums.length === 0) {
        // Unable to fix failing checksum with 1 ambigious character
        return `${accountNumber} ERR\n`;
      } else if (validChecksums.length === 1) {
        // Found a single valid checksum, using
        let newAccountNumber = accountNumber.replace(
          "?",
          `${validChecksums[0].number.value}`
        );
        return `${newAccountNumber}\n`;
      } else {
        // Multiple passing checksums, ambiguous account number
        return `${accountNumber} AMB\n`;
      }
    } else {
      // Ran out of time on handling multiple ? in account number
      // Idea here would have been to iterate through potentialMatches and using those to generate all
      // possible account numbers from the available data. Then, we would check if any of those account
      // numbers had valid checksums
      console.log("todo: handle multi ambigious stuff; for now it's illegible");
      return `${accountNumber} ILL\n`;
    }
  }
}
