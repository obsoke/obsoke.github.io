import { readFile, writeFile } from "fs/promises";
import * as OCR from "./ocr";

const outputFolder = "/tmp";

async function main() {
  if (process.argv.length != 3) {
    console.error("ERROR: Expected usage: npm run <source_file>");
    process.exit(1);
  }

  const fileName = process.argv[2];
  console.log("Welcome to the Bank OCR Tool!");
  console.log(`Reading ${fileName}`);

  let outputFileContents = "";
  const fileContents = await readFile(fileName, { encoding: "utf8" });
  const fileSplitByLine = fileContents.split("\n");
  for (let row = 0; row + 4 < fileSplitByLine.length; row += 4) {
    const accountNumberLines = [
      fileSplitByLine[row],
      fileSplitByLine[row + 1],
      fileSplitByLine[row + 2],
      fileSplitByLine[row + 3],
    ];

    const accountNumberLine = OCR.processAccountNumberLines(accountNumberLines);
    outputFileContents += accountNumberLine;
  }

  const outputFileName = `${outputFolder}/ocr-results-${Date.now()}.txt`;
  await writeFile(outputFileName, outputFileContents, { encoding: "utf8" });
  console.log(`Account file processed, output available at ${outputFileName}`);
}

main();
