import * as OCR from "./ocr";

describe("single digit recognition", () => {
  test("correctly recognizes a 0", () => {
    // prettier-ignore
    const ascii0 = [
            " ", "_", " ",
            "|", " ", "|",
            "|", "_", "|"
    ];
    const result = OCR.identifyDigit(ascii0);
    expect(result?.potentialMatches[0].number.value).toBe(0);
  });

  test("correctly recognizes a 1", () => {
    // prettier-ignore
    const ascii1 = [
            " ", " ", " ",
            " ", " ", "|",
            " ", " ", "|"
    ];
    const result = OCR.identifyDigit(ascii1);
    expect(result?.potentialMatches[0].number.value).toBe(1);
  });

  test("correctly recognizes a 8", () => {
    // prettier-ignore
    const ascii8 = [
            " ", "_", " ",
            "|", "_", "|",
            "|", "_", "|"
    ];
    const result = OCR.identifyDigit(ascii8);
    expect(result.potentialMatches[0].number.value).toBe(8);
  });

  test("correctly recognizes a 9", () => {
    // prettier-ignore
    const ascii9 = [
            " ", "_", " ",
            "|", "_", "|",
            " ", "_", "|"
    ];
    const result = OCR.identifyDigit(ascii9);
    expect(result.potentialMatches[0].number.value).toBe(9);
  });
});

/**
 * In this scenario, we imagine that we are reading/streaming a file line-by-line
 * so we can feed these functions the 4 lines they expect (3 with account number + 1 blank)
 */
describe("account number recognition", () => {
  test("correctly recognizes account #000000000", () => {
    const account000000000 = [
      " _  _  _  _  _  _  _  _  _ ",
      "| || || || || || || || || |",
      "|_||_||_||_||_||_||_||_||_|",
      "",
    ];
    const result = OCR.decodeAccountNumber(account000000000);
    expect(result.accountNumber).toBe("000000000");
  });

  test("correctly recognizes account #123456789", () => {
    const account123456789 = [
      "    _  _     _  _  _  _  _ ",
      "  | _| _||_||_ |_   ||_||_|",
      "  ||_  _|  | _||_|  ||_| _|",
      "",
    ];
    const result = OCR.decodeAccountNumber(account123456789);
    expect(result.accountNumber).toBe("123456789");
  });

  test("correctly recognizes account #490867715", () => {
    const account490867715 = [
      "    _  _  _  _  _  _     _ ",
      "|_||_|| ||_||_   |  |  ||_ ",
      "  | _||_||_||_|  |  |  | _|",
      "",
    ];
    const result = OCR.decodeAccountNumber(account490867715);
    expect(result.accountNumber).toBe("490867715");
  });
});

describe("validate account number checksum", () => {
  test("confirm #000000000 has a valid checksum", () => {
    const account000000000 = "000000000";
    const result = OCR.isChecksumValid(account000000000);
    expect(result).toBeTruthy();
  });

  test("confirm #345882865 has a valid checksum", () => {
    const account345882865 = "345882865";
    const result = OCR.isChecksumValid(account345882865);
    expect(result).toBeTruthy();
  });

  test("confirm #457508000 has a valid checksum", () => {
    const account457508000 = "457508000";
    const result = OCR.isChecksumValid(account457508000);
    expect(result).toBeTruthy();
  });

  test("confirm #345882869 has an invalid checksum", () => {
    const account345882869 = "345883847";
    const result = OCR.isChecksumValid(account345882869);
    expect(result).toBeFalsy();
  });
});

describe("determine final output for account number", () => {
  // TODO: ran out of time to ensure use case 4 worked
  // test("#777777177 should output '777777177'", () => {
  //   const accountNum = [
  //     " _  _  _  _  _  _  _  _  _ ",
  //     "  |  |  |  |  |  |  |  |  |",
  //     "  |  |  |  |  |  |  |  |  |",
  //     "",
  //   ];
  //   const result = OCR.processAccountNumberLines(accountNum);
  //   expect(result).toBe("777777177");
  // });
});
