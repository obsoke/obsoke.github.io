# Bank OCR for Test Double by Dale Karp

This is my submission for Test Double's take home interview.

Overall, I found this to be a challenging take home question. There was quite a bit to consider & work on within the 3 hour limit. I didn't quite finish making sure case #4 worked correctly due to time.

## Installation

Install required packages with NPM:

```shell
npm i
```

## Tests

Test can be ran via NPM as well:

```shell
npm t
```

## Using the test data

The entry point for the program takes a file path as its only argument in order to process the file.
Try the following test files. The output will be written to a file in `/tmp`. The exact file name will be output to the console.

```shell
npm start ./tests/test_case3.txt
npm start ./tests/test_only_0s.txt
```
