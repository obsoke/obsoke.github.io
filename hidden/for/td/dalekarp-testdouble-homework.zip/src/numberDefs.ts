import type { OCRNumber } from "./ocr";

export const OCR_NUMBERS: OCRNumber[] = [
  {
    value: 0,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            "|", " ", "|",
            "|", "_", "|"
        ],
  },
  {
    value: 1,
    // prettier-ignore
    representation: [
            " ", " ", " ",
            " ", " ", "|",
            " ", " ", "|"
        ],
  },
  {
    value: 2,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            " ", "_", "|",
            "|", "_", " "
        ],
  },
  {
    value: 3,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            " ", "_", "|",
            " ", "_", "|"
        ],
  },
  {
    value: 4,
    // prettier-ignore
    representation: [
            " ", " ", " ",
            "|", "_", "|",
            " ", " ", "|"
        ],
  },
  {
    value: 5,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            "|", "_", " ",
            " ", "_", "|"
        ],
  },
  {
    value: 6,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            "|", "_", " ",
            "|", "_", "|"
        ],
  },

  {
    value: 7,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            " ", " ", "|",
            " ", " ", "|"
        ],
  },
  {
    value: 8,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            "|", "_", "|",
            "|", "_", "|"
        ],
  },
  {
    value: 9,
    // prettier-ignore
    representation: [
            " ", "_", " ",
            "|", "_", "|",
            " ", "_", "|"
        ],
  },
];
